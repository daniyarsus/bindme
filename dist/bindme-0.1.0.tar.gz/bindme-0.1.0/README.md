# bindme
Simple DI Framework for Python 3.x 🐍
